			</div><!-- .sections_group -->
		</div><!-- .content_wrapper -->
	</div><!-- #Content -->
	
	<footer id="Footer" class="clearfix">
		<div class="footer_copy">
			<div class="container">
				<div class="column one">
					<div class="copyright">
						&copy; <?php echo esc_html( gmdate( 'Y' ) ); ?> <?php echo esc_html( get_bloginfo( 'name' ) ); ?>. All rights reserved.
					</div>
					<ul class="social">
						<!-- Social links can be added here -->
					</ul>
				</div>
			</div>
		</div>
	</footer>
	
</div><!-- #Wrapper -->

<?php wp_footer(); ?>

</body>
</html>
